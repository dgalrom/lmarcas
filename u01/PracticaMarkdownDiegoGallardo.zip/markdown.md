# Práctica 1: Markdown

## Alumno: Diego Gallardo Román

**Markdown** es un lenguaje de marcado ligero creado por _John Gruber_ y _Aaron Swartz_ que trata de conseguir la **máxima legibilidad** y **facilidad de publicación** tanto en su forma de _entrada_ como de _salida_.

### Código preformateado

    public static void main(String[] args) {
    	System.out.println("Hola Mundo!");

    }

### Lista Ordenada

1. Almendras
2. Bistec
3. Peras

### Lista No-Ordenada

- Sevilla
- Alicante
- Zaragoza

### Enlace

[Mi perfil de Github](https://github.com/dgalrom)

### Imagen

![Transbordador](https://i.pinimg.com/564x/40/39/1f/40391f4f31b408e51eb6887a615ce408.jpg)

### Tabla

| Edificios       | Ciudad    |
| --------------- | --------- |
| Torre Cepsa     | Madrid    |
| Torre Mapfre    | Barcelona |
| Torre Iberdrola | Bilbao    |
